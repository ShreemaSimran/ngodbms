﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ngodbms
{
    public partial class cmlogin_UserControl : UserControl
    {
        private static cmlogin_UserControl _instance;
        public static cmlogin_UserControl Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new cmlogin_UserControl();
                }
                return _instance;
            }
        }
        public cmlogin_UserControl()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';
        }

        private void cmlogin_UserControl_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
            SqlCommand cmd = new SqlCommand("Select * from clogin where c_username='" + textBox1.Text + "' and c_pwd='" + textBox2.Text + "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count >= 1)
            {
                Hide();
                cmhome cmh = new cmhome(textBox1.Text);
                cmh.Show();
                MessageBox.Show("Welcome Committee Member");
            }
            else
            {
                MessageBox.Show("Incorrect credentials");
            }
            
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Hide();
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
