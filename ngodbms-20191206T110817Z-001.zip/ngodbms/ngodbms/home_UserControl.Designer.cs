﻿namespace ngodbms
{
    partial class home_UserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(home_UserControl));
            this.homelabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // homelabel
            // 
            this.homelabel.BackColor = System.Drawing.Color.Transparent;
            this.homelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homelabel.ForeColor = System.Drawing.Color.Black;
            this.homelabel.Location = new System.Drawing.Point(96, 12);
            this.homelabel.Name = "homelabel";
            this.homelabel.Size = new System.Drawing.Size(106, 23);
            this.homelabel.TabIndex = 0;
            this.homelabel.Text = "HOME";
            this.homelabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.homelabel.Click += new System.EventHandler(this.homelabel_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::ngodbms.Properties.Resources.Screenshot_20181004_221236;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(82, 38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(136, 120);
            this.panel1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(299, 236);
            this.label3.TabIndex = 4;
            this.label3.Text = resources.GetString("label3.Text");
            // 
            // home_UserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.homelabel);
            this.DoubleBuffered = true;
            this.Name = "home_UserControl";
            this.Size = new System.Drawing.Size(498, 404);
            this.Load += new System.EventHandler(this.home_UserControl_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label homelabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
    }
}
