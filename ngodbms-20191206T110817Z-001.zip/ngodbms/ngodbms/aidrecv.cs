﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace ngodbms
{
    public partial class aidrecv : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int IParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        public aidrecv()
        {
            InitializeComponent();
        }
        public aidrecv(String str_v)
        {
            InitializeComponent();
            textBox1.Text = str_v;

        }

        private void button12_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }
       // SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True");
        //Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=\Database.mdf;Integrated Security = True
         private void button2_Click(object sender, EventArgs e)
        {
            /*  con.Open();
              SqlCommand cmd = con.CreateCommand();
              cmd.CommandType = CommandType.Text;
              cmd.CommandText = "Insert into AIR Values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox5.Text + "','" + richTextBox1.Text + "')";
              cmd.ExecuteNonQuery();
              con.Close();
              dispdata();
              textBox1.Text = "";
              textBox2.Text = "";
              textBox5.Text = "";
              richTextBox1.Text = "";*/
            SqlCommand cmd = new SqlCommand("aid_r", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@A_Id", textBox1.Text);
            cmd.Parameters.AddWithValue("@A_Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@Phone", textBox5.Text);
            cmd.Parameters.AddWithValue("@Address", richTextBox1.Text);
            con.Open();
            try {
                cmd.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                MessageBox.Show("      <<<INVALID SQL OPERATION>> \n" + ex);
            }
            con.Close();
            refresh_DataGridView1();
            MessageBox.Show("The aid receiver details was saved successfully");
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        

    }
    /*public void dispdata()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from AIR";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }*/
        public void refresh_DataGridView1()
        {
        try {
                SqlCommand cmd = new SqlCommand("ar", con);
                cmd.CommandType=CommandType.StoredProcedure;
                SqlDataAdapter db = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                db.Fill(ds);
                con.Open();
                try {
                    cmd.ExecuteNonQuery();
                }
                catch(Exception ex)
                {
                    MessageBox.Show("    <<INVALID SQL OPERATION >>; \n" + ex);
                }
                con.Close();
                dataGridView1.DataSource = ds.Tables[0];

        }
        catch(Exception ex)
        {
                MessageBox.Show(" " + ex);
        }
        }
       
        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void aidrecv_Load(object sender, EventArgs e)
        {
            con.Open();
            string str = "select * from AIR where A_ID='" + textBox1.Text + "'";
            SqlCommand cmd = con.CreateCommand();
            cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                textBox2.Text = reader["A_Name"].ToString();
                textBox5.Text = reader["Phone"].ToString();
                richTextBox1.Text = reader["Address"].ToString();
            }
            con.Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd = new SqlCommand("update AIR  SET A_Name=@a1,  Phone=@a5,Address=@a7 where A_Id=@a8 ", con);
            cmd.Parameters.Add("a1", textBox2.Text);
            cmd.Parameters.Add("a5", textBox5.Text);
            cmd.Parameters.Add("a7", richTextBox1.Text);
            cmd.Parameters.Add("a8", (textBox1.Text));
            cmd.ExecuteNonQuery();
            con.Close();
            refresh_DataGridView1();
            MessageBox.Show("The aid receiver details was saved successfully");
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();

        }
    }
}
