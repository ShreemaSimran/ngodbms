﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ngodbms
{

    public partial class home_UserControl : UserControl
    {
        private static home_UserControl _instance;

        public static home_UserControl Instance
        {
            get
            {
                if(_instance==null)
                {
                    _instance = new home_UserControl();
                }
                return _instance;
            }
        }
        public home_UserControl()
        {
            InitializeComponent();
        }

        private void home_UserControl_Load(object sender, EventArgs e)
        {

        }

        private void homelabel_Click(object sender, EventArgs e)
        {

        }
    }
}
