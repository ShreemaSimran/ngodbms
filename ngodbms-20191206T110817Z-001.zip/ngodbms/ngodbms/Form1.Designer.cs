﻿namespace ngodbms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.slidingpaneltimer = new System.Windows.Forms.Timer(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.cpanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.slidingpanel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.about = new System.Windows.Forms.Button();
            this.doner = new System.Windows.Forms.Button();
            this.volunteer_member_login = new System.Windows.Forms.Button();
            this.committee_member_login = new System.Windows.Forms.Button();
            this.admin_login = new System.Windows.Forms.Button();
            this.home = new System.Windows.Forms.Button();
            this.slidingpaneltogglebutton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cpanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.slidingpanel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // slidingpaneltimer
            // 
            this.slidingpaneltimer.Interval = 50;
            this.slidingpaneltimer.Tick += new System.EventHandler(this.slidingpaneltimer_Tick);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // cpanel
            // 
            this.cpanel.BackColor = System.Drawing.Color.White;
            this.cpanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.cpanel.Controls.Add(this.panel1);
            this.cpanel.Location = new System.Drawing.Point(186, 22);
            this.cpanel.Name = "cpanel";
            this.cpanel.Size = new System.Drawing.Size(498, 404);
            this.cpanel.TabIndex = 2;
            this.cpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.cpanel_Paint);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::ngodbms.Properties.Resources.Screenshot_20181004_221236;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(0, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(495, 401);
            this.panel1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tekton Pro Cond", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MediumBlue;
            this.label2.Location = new System.Drawing.Point(134, 363);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(224, 29);
            this.label2.TabIndex = 3;
            this.label2.Text = "Shine Brightly In One\'s Life ";
            // 
            // slidingpanel
            // 
            this.slidingpanel.BackColor = System.Drawing.Color.RoyalBlue;
            this.slidingpanel.BackgroundImage = global::ngodbms.Properties.Resources.download1;
            this.slidingpanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slidingpanel.Controls.Add(this.button1);
            this.slidingpanel.Controls.Add(this.label1);
            this.slidingpanel.Controls.Add(this.about);
            this.slidingpanel.Controls.Add(this.doner);
            this.slidingpanel.Controls.Add(this.volunteer_member_login);
            this.slidingpanel.Controls.Add(this.committee_member_login);
            this.slidingpanel.Controls.Add(this.admin_login);
            this.slidingpanel.Controls.Add(this.home);
            this.slidingpanel.Controls.Add(this.slidingpaneltogglebutton);
            this.slidingpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.slidingpanel.Font = new System.Drawing.Font("Tekton Pro Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slidingpanel.Location = new System.Drawing.Point(0, 0);
            this.slidingpanel.Margin = new System.Windows.Forms.Padding(4);
            this.slidingpanel.Name = "slidingpanel";
            this.slidingpanel.Size = new System.Drawing.Size(186, 426);
            this.slidingpanel.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(128, 214);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(8, 8);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Image = global::ngodbms.Properties.Resources.home;
            this.label1.Location = new System.Drawing.Point(3, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 19);
            this.label1.TabIndex = 3;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // about
            // 
            this.about.BackColor = System.Drawing.Color.Transparent;
            this.about.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.about.Font = new System.Drawing.Font("Tekton Pro Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.about.Image = global::ngodbms.Properties.Resources.icons8_about_26;
            this.about.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.about.Location = new System.Drawing.Point(0, 291);
            this.about.Margin = new System.Windows.Forms.Padding(4);
            this.about.Name = "about";
            this.about.Size = new System.Drawing.Size(186, 53);
            this.about.TabIndex = 2;
            this.about.Text = "ABOUT";
            this.about.UseVisualStyleBackColor = false;
            this.about.Click += new System.EventHandler(this.about_Click);
            // 
            // doner
            // 
            this.doner.BackColor = System.Drawing.Color.Transparent;
            this.doner.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.doner.Font = new System.Drawing.Font("Tekton Pro Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doner.Image = global::ngodbms.Properties.Resources.icons8_coins_24;
            this.doner.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.doner.Location = new System.Drawing.Point(0, 244);
            this.doner.Margin = new System.Windows.Forms.Padding(4);
            this.doner.Name = "doner";
            this.doner.Size = new System.Drawing.Size(186, 53);
            this.doner.TabIndex = 1;
            this.doner.Text = "DONER";
            this.doner.UseVisualStyleBackColor = false;
            this.doner.Click += new System.EventHandler(this.doner_Click);
            // 
            // volunteer_member_login
            // 
            this.volunteer_member_login.BackColor = System.Drawing.Color.Transparent;
            this.volunteer_member_login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.volunteer_member_login.Font = new System.Drawing.Font("Tekton Pro Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.volunteer_member_login.Image = global::ngodbms.Properties.Resources.icons8_people_26;
            this.volunteer_member_login.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.volunteer_member_login.Location = new System.Drawing.Point(0, 192);
            this.volunteer_member_login.Margin = new System.Windows.Forms.Padding(4);
            this.volunteer_member_login.Name = "volunteer_member_login";
            this.volunteer_member_login.Size = new System.Drawing.Size(186, 53);
            this.volunteer_member_login.TabIndex = 1;
            this.volunteer_member_login.Text = "VOLUNTEER MEMBER LOGIN";
            this.volunteer_member_login.UseVisualStyleBackColor = false;
            this.volunteer_member_login.Click += new System.EventHandler(this.button5_Click);
            // 
            // committee_member_login
            // 
            this.committee_member_login.BackColor = System.Drawing.Color.Transparent;
            this.committee_member_login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.committee_member_login.Font = new System.Drawing.Font("Tekton Pro Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.committee_member_login.Image = global::ngodbms.Properties.Resources.icons8_conference_26;
            this.committee_member_login.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.committee_member_login.Location = new System.Drawing.Point(0, 142);
            this.committee_member_login.Margin = new System.Windows.Forms.Padding(4);
            this.committee_member_login.Name = "committee_member_login";
            this.committee_member_login.Size = new System.Drawing.Size(186, 53);
            this.committee_member_login.TabIndex = 1;
            this.committee_member_login.Text = "COMMITTEE MEMBER LOGIN";
            this.committee_member_login.UseVisualStyleBackColor = false;
            this.committee_member_login.Click += new System.EventHandler(this.committee_member_login_Click);
            // 
            // admin_login
            // 
            this.admin_login.BackColor = System.Drawing.Color.Transparent;
            this.admin_login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.admin_login.Font = new System.Drawing.Font("Tekton Pro Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admin_login.Image = global::ngodbms.Properties.Resources.icons8_businessman_26__1_;
            this.admin_login.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.admin_login.Location = new System.Drawing.Point(0, 100);
            this.admin_login.Margin = new System.Windows.Forms.Padding(4);
            this.admin_login.Name = "admin_login";
            this.admin_login.Size = new System.Drawing.Size(186, 53);
            this.admin_login.TabIndex = 1;
            this.admin_login.Text = "ADMIN LOGIN";
            this.admin_login.UseVisualStyleBackColor = false;
            this.admin_login.Click += new System.EventHandler(this.admin_login_Click);
            // 
            // home
            // 
            this.home.BackColor = System.Drawing.Color.Transparent;
            this.home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.home.Font = new System.Drawing.Font("Tekton Pro Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.home.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.home.ImageKey = "(none)";
            this.home.Location = new System.Drawing.Point(0, 48);
            this.home.Margin = new System.Windows.Forms.Padding(4);
            this.home.Name = "home";
            this.home.Size = new System.Drawing.Size(186, 53);
            this.home.TabIndex = 1;
            this.home.Text = "HOME";
            this.home.UseVisualStyleBackColor = false;
            this.home.Click += new System.EventHandler(this.home_Click);
            // 
            // slidingpaneltogglebutton
            // 
            this.slidingpaneltogglebutton.BackColor = System.Drawing.Color.Transparent;
            this.slidingpaneltogglebutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.slidingpaneltogglebutton.Image = global::ngodbms.Properties.Resources.icons8_double_left_26;
            this.slidingpaneltogglebutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.slidingpaneltogglebutton.Location = new System.Drawing.Point(0, 0);
            this.slidingpaneltogglebutton.Margin = new System.Windows.Forms.Padding(4);
            this.slidingpaneltogglebutton.Name = "slidingpaneltogglebutton";
            this.slidingpaneltogglebutton.Size = new System.Drawing.Size(186, 52);
            this.slidingpaneltogglebutton.TabIndex = 0;
            this.slidingpaneltogglebutton.UseVisualStyleBackColor = false;
            this.slidingpaneltogglebutton.Click += new System.EventHandler(this.slidingpaneltogglebutton_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImage = global::ngodbms.Properties.Resources.icons8_minimize_window_161;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button3.Location = new System.Drawing.Point(448, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(26, 25);
            this.button3.TabIndex = 5;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImage = global::ngodbms.Properties.Resources.icons8_cancel_161;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button2.Location = new System.Drawing.Point(471, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(26, 25);
            this.button2.TabIndex = 4;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Location = new System.Drawing.Point(186, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(498, 26);
            this.panel2.TabIndex = 6;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 426);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.cpanel);
            this.Controls.Add(this.slidingpanel);
            this.Font = new System.Drawing.Font("Tekton Pro Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "NGO DATABASE MANAGEMENT SYSTEM";
            this.cpanel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.slidingpanel.ResumeLayout(false);
            this.slidingpanel.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel slidingpanel;
        private System.Windows.Forms.Button slidingpaneltogglebutton;
        private System.Windows.Forms.Timer slidingpaneltimer;
        private System.Windows.Forms.Button doner;
        private System.Windows.Forms.Button volunteer_member_login;
        private System.Windows.Forms.Button committee_member_login;
        private System.Windows.Forms.Button about;
        private System.Windows.Forms.Button admin_login;
        private System.Windows.Forms.Button home;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Panel cpanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel2;
    }
}

