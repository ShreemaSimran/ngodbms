﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ngodbms
{
    public partial class cmhome : Form
    {
        public cmhome(String str_value)
        {
            InitializeComponent();
            label14.Text = str_value;
        }
        public cmhome()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Hide();
            lcm1 lcm = new lcm1();
            lcm.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Hide();
            lod1 ld = new lod1();
            ld.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            trans1 t = new trans1();
            t.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Hide();
            lar1 lar = new lar1();
            lar.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Hide();
            acm1 ecm = new acm1(label13.Text, label14.Text, label15.Text, label16.Text, label17.Text);
            ecm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
            lvm1 lvm = new lvm1();
            lvm.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Hide();
            addm am = new addm();
            am.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Hide();
            rmvm rm = new rmvm();
            rm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            editm em = new editm();
            em.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            Hide();
            aidrecv arc = new aidrecv();
            arc.Show();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Hide();
            EDITAR ear = new EDITAR();
            ear.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Hide();
            adddoner ad = new adddoner();
            ad.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Hide();
            editd ed = new editd();
            ed.Show();
        }

        private void button12_Click_1(object sender, EventArgs e)
        {
            Hide();
            withdraw wd = new withdraw();
            wd.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You have successfully logged out");
            Environment.Exit(0);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are in Home");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You have been logged out");
            Environment.Exit(0);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
        private void cmhome_Load(object sender, EventArgs e)
        {
            this.Opacity = 0.1;
            timer1.Start();
            con.Open();
            string str = "select * from LCM where CM_ID= '"+label14.Text+"'  ";
            SqlCommand cmd = con.CreateCommand();
            cmd = new SqlCommand(str, con);
            SqlDataReader reader =cmd.ExecuteReader();
            while(reader.Read())
            {
                label13.Text = reader["NAME"].ToString();
                //label14.Text = reader["CM_ID"].ToString();
                label15.Text = reader["POSITION"].ToString();
                label16.Text = reader["DOA"].ToString();
                label17.Text = reader["V_ID"].ToString();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(this.Opacity<=1.0)
            {
                this.Opacity += 0.025;
            }
            else
            {
                timer1.Stop();
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }
    }
}
