﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace ngodbms
{
    public partial class acm1 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int IParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        //private SqlConnection con;
       // private SqlCommand cmd;

        public acm1()
        {
            InitializeComponent();
        }
        public acm1(String str_v,String str_vi,String str_v1,String str_v2,String str_v3)
        {
            InitializeComponent();
            textBox1.Text = str_v;
            textBox2.Text = str_vi;
            textBox5.Text = str_v1;
            dateTimePicker1.Text = str_v2;
            textBox3.Text = str_v3;
        }
        private void button12_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
        private void button2_Click(object sender, EventArgs e)
        {
           /*con.Open();
           SqlCommand cmd = con.CreateCommand();
           cmd.CommandType = CommandType.Text;
            cmd.CommandText = "UPDATE LCM set NAME='" + textBox1.Text + "',POSITION='" + textBox3.Text + "',DOA='" + dateTimePicker1.Text + "'where CM_ID='" + textBox2.Text + "' AND V_ID='" + textBox5.Text + "'";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();

          cmd.CommandText = "Insert into LCM Values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox5.Text + "','" + dateTimePicker1.Text + "','" + textBox3.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
             textBox1.Text = "";
           textBox2.Text = "";
            textBox3.Text = "";
            dateTimePicker1.Text = "";
            textBox5.Text = "";*/
           

         //  con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = D:\ngodbms\ngodbms\Database.mdf; Integrated Security = True");
           con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
             cmd = new SqlCommand("update LCM  SET NAME=@a1, POSITION=@a2, DOA=@a3, V_ID=@a4 where CM_ID=@a5 ", con);
                 cmd.Parameters.Add("a1",textBox1.Text);
                  cmd.Parameters.Add("a2", textBox5.Text);
                  cmd.Parameters.Add("a3", dateTimePicker1.Text);
                  cmd.Parameters.Add("a4", textBox3.Text);
                  cmd.Parameters.Add("a5",(textBox2.Text));
                  cmd.ExecuteNonQuery();

            MessageBox.Show("The changes are saved successfully");
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

      // SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
        private void acm1_Load(object sender, EventArgs e)
        {
            
        }

        private void acm1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
