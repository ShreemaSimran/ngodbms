﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace ngodbms
{
    public partial class adminhome : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int IParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public adminhome()
        {
            InitializeComponent();
            Form1 f1 = new Form1();
            f1.WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hide();
            listvm l1 = new listvm();
            l1.Show();
            this.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Opacity = 1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            trans t = new trans();
            t.Show();
        }
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Hide();
            listofar ar = new listofar();
            ar.Show();
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Hide();
            listofd d = new listofd();
            d.Show();
            
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            editcm ecm = new editcm();
            ecm.Show();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
            listcm lcm = new listcm();
            lcm.Show();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Hide();
            addcm acm = new addcm();
            acm.Show();
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Hide();
            rmvcm rmcm = new rmvcm();
            rmcm.Show();
            
        }

        private void adminhome_Load(object sender, EventArgs e)
        {
            Hide();
            this.Opacity = 0.1;
            admin_lt.Start();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Hide();
            editcm ecm = new editcm();
            ecm.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Hide();
            listvm lvm = new listvm();
            lvm.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Hide();
            trans t = new trans();
            t.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            Hide();
            listofar lar = new listofar();
            lar.Show();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            Hide();
            listofd ld = new listofd();
            ld.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Hide();
            listcm lcm = new listcm();
            lcm.Show();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            Hide();
            addcm acm = new addcm();
            acm.Show();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            Hide();
            rmvcm rmcm = new rmvcm();
            rmcm.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are at admin Home");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Hide();
            MessageBox.Show("You have been successfully logged out");
            Environment.Exit(0);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You have been logged out");
            Environment.Exit(0);
        }
        private void panel4_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {
          
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void admin_lt_Tick(object sender, EventArgs e)
        {
            if(this.Opacity<=1)
            {
                this.Opacity += 0.025;
            }
            else
            {
                admin_lt.Stop();
            }
        }

        private void label6_Click_1(object sender, EventArgs e)
        {

        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

      
       

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
