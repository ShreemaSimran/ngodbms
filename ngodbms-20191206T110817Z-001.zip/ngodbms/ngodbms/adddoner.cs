﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace ngodbms
{
    public partial class adddoner : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int IParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        public adddoner()
        {
            InitializeComponent();
        }
        public adddoner(String str_v)
        {
            InitializeComponent();
            textBox1.Text = str_v;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Insert into DONOR Values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + dateTimePicker1.Text + "','" + dateTimePicker2.Text + "','" + textBox5.Text + "','" + Gender + "','" + richTextBox1.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            dateTimePicker1.Text = "";
            dateTimePicker2.Text = "";
            textBox5.Text = "";
            Gender = "";
            richTextBox1.Text = "";
            //textBox4.Text = "";
            MessageBox.Show("The Data was saved successfully");
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void adddoner_Load(object sender, EventArgs e)
        {
            con.Open();
            string str = "select D_Id,Name,Amount,DOB,DON,Phone,Address from DONOR where D_Id='" +textBox1.Text+ "'";
            SqlCommand cmd = con.CreateCommand();
            cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                textBox2.Text = reader["Name"].ToString();
                textBox3.Text = reader["Amount"].ToString();
                dateTimePicker1.Text = reader["DOB"].ToString();
                dateTimePicker2.Text = reader["DON"].ToString();
                textBox5.Text = reader["Phone"].ToString();
                richTextBox1.Text = reader["Address"].ToString();
            }
            con.Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        String Gender;
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Female";
        }

        public void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Male";
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd = new SqlCommand("update DONOR  SET Name=@a1, Amount=@a2, DOB=@a3,DON=@a4, Phone=@a5,Gender=@a6,Address=@a7 where D_Id=@a8 ", con);
            cmd.Parameters.Add("a1", textBox2.Text);
            cmd.Parameters.Add("a2", textBox3.Text);
            cmd.Parameters.Add("a3", dateTimePicker1.Text);
            cmd.Parameters.Add("a4", dateTimePicker2.Text);
            cmd.Parameters.Add("a5", textBox5.Text);
            cmd.Parameters.Add("a6", Gender);
            cmd.Parameters.Add("a7", richTextBox1.Text);
            cmd.Parameters.Add("a8", (textBox1.Text));
            cmd.ExecuteNonQuery();
            MessageBox.Show("The Data was updated successfully");
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }
    }
}
