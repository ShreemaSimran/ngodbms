﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ngodbms
{
    public partial class addm : Form
    {
        public addm()
        {
            InitializeComponent();
        }
        public addm(String str_v)
        {
            InitializeComponent();
            textBox1.Text = str_v;
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }
        String Gender;
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Insert into LVM Values('" + textBox1.Text + "','" + textBox2.Text + "','" + dateTimePicker1.Text + "','" + dateTimePicker2.Text + "','" + textBox5.Text + "','" + Gender + "','" + richTextBox1.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            
            textBox1.Text = "";
            textBox2.Text = "";
            dateTimePicker1.Text = "";
            dateTimePicker2.Text = "";
            textBox5.Text = "";
            Gender = "";
            richTextBox1.Text = "";
            MessageBox.Show("The Volunteer member was added successfully");
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Male";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Female";
        }

        private void addm_Load(object sender, EventArgs e)
        {

            con.Open();
            string str = "select V_ID,Name,DOB,DOJ,Phone,Address from LVM where V_ID='" + textBox1.Text + "'";
            SqlCommand cmd = con.CreateCommand();
            cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                textBox2.Text = reader["Name"].ToString();
                dateTimePicker1.Text = reader["DOB"].ToString();
                dateTimePicker2.Text = reader["DOJ"].ToString();
                textBox5.Text = reader["Phone"].ToString();
                richTextBox1.Text = reader["Address"].ToString();
            }
            con.Close();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd = new SqlCommand("update LVM  SET Name=@a1,  DOB=@a3,DOJ=@a4, Phone=@a5,Gender=@a6,Address=@a7 where V_ID=@a8 ", con);
            cmd.Parameters.Add("a1", textBox2.Text);
            //cmd.Parameters.Add("a2", textBox3.Text);
            cmd.Parameters.Add("a3", dateTimePicker1.Text);
            cmd.Parameters.Add("a4", dateTimePicker2.Text);
            cmd.Parameters.Add("a5", textBox5.Text);
            cmd.Parameters.Add("a6", Gender);
            cmd.Parameters.Add("a7", richTextBox1.Text);
            cmd.Parameters.Add("a8", (textBox1.Text));
            cmd.ExecuteNonQuery();
            MessageBox.Show("The Volunteer member was updated successfully");
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }
    }
}
