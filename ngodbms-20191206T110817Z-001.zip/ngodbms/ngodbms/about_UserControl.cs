﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ngodbms
{
    public partial class about_UserControl : UserControl
    {
        private static about_UserControl _instance;
        public static about_UserControl Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new about_UserControl();
                }
                return _instance;
            }
        }
        public about_UserControl()
        {
            InitializeComponent();
        }

        private void about_UserControl_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
