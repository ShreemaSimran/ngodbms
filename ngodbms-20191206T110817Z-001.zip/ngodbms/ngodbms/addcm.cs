﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace ngodbms
{
    public partial class addcm : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int IParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        public addcm()
        {
            InitializeComponent();
        }
        public addcm(String str_v1)
        {
            InitializeComponent();
            textBox2.Text = str_v1;
        }


        public void addcm_Load(object sender, EventArgs e)
        {
            con.Open();
            string str = "select * from LCM where CM_ID='"+textBox2.Text+"'";
            SqlCommand cmd = con.CreateCommand();
            cmd = new SqlCommand(str, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                textBox1.Text= reader["NAME"].ToString();
                //label14.Text = reader["CM_ID"].ToString();
                textBox3.Text = reader["POSITION"].ToString();
                dateTimePicker1.Text = reader["DOA"].ToString();
                textBox5.Text = reader["V_ID"].ToString();
            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            adminhome ah = new adminhome();
            ah.Show();
        }

        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Insert into LCM Values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + dateTimePicker1.Text + "','" + textBox5.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            dispdata();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            dateTimePicker1.Text = "";
            textBox5.Text = "";
            MessageBox.Show("The entered committee member detail was saved successfully");
            Hide();
            adminhome ah = new adminhome();
            ah.Show();
        }
        public void dispdata()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from LCM";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Hide();
            adminhome ah = new adminhome();
            ah.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Hide();
            adminhome ah = new adminhome();
            ah.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

       private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

       private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            con.Open();
             SqlCommand cmd = con.CreateCommand();
             cmd.CommandType = CommandType.Text;
             cmd = new SqlCommand("update LCM  SET NAME=@a1, POSITION=@a2, DOA=@a3,V_ID=@a4 where CM_ID=@a5   ", con);
             cmd.Parameters.Add("a1", textBox1.Text);
             cmd.Parameters.Add("a2", textBox3.Text);
             cmd.Parameters.Add("a3", dateTimePicker1.Text);
             cmd.Parameters.Add("a4", textBox5.Text);
             cmd.Parameters.Add("a5", (textBox2.Text));
             cmd.ExecuteNonQuery();
            con.Close();
            dispdata();
           
              MessageBox.Show("Committee member detail was updated successfully");
             Hide();
             adminhome ah = new adminhome();
             ah.Show();
            
        }
    }
}
