﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ngodbms
{
    public partial class alogin_UserControl : UserControl
    {
        private static alogin_UserControl _instance;
        public static alogin_UserControl Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new alogin_UserControl();
                }
                return _instance;
            }
        }

        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        private String getUsername()
        {
            con.Open();
            String syntax = "SELECT VALUE FROM alogin where PROPERTY='USERNAME'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            String temp=dr[0].ToString();
            con.Close();
            return temp;
        }


        private String getPassword()
        {
            con.Open();
            String syntax = "SELECT VALUE FROM alogin where PROPERTY='PASSWORD'";
            cmd = new SqlCommand(syntax, con);
            dr = cmd.ExecuteReader();
            dr.Read();
            String temp = dr[0].ToString();
            con.Close();
            return temp;
        }


        public alogin_UserControl()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';

        }

        private void alogin_UserControl_Load(object sender, EventArgs e)
        {
            label3.Hide();
        }

        private void USERNAME_Click(object sender, EventArgs e)
        {

        }

        private void PASSWORD_Click(object sender, EventArgs e)
        {

        }

        private void USERNAME_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            adminhome ah = new adminhome();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            String uname=getUsername(), upass=getPassword(), name, pass;
            name = textBox1.Text;
            pass = textBox2.Text;

            if(name.Equals(uname) && pass.Equals(upass))
            {
                label3.Hide();
                Hide();
                Form1 f1 = new Form1();
                f1.Hide();
                MessageBox.Show("Welcome Admin");
                adminhome ah = new adminhome();
                ah.Show();
            }

            else
            {
                label3.Show();
            }
                        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {

        }
    }
}
