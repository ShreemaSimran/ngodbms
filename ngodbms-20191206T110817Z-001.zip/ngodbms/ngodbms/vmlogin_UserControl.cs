﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ngodbms
{
    public partial class vmlogin_UserControl : UserControl
    {
        private static vmlogin_UserControl _instance;
        public static vmlogin_UserControl Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new vmlogin_UserControl();
                }
                return _instance;
            }
        }
        public vmlogin_UserControl()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';
        }

        private void vmlogin_UserControl_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
            SqlCommand cmd = new SqlCommand("Select * from vlogin where v_username='" + textBox1.Text + "' and v_pwd='" + textBox2.Text + "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count >= 1)
            {
                Hide();
                vmhome vmh = new vmhome(textBox1.Text);
                vmh.Show();
                MessageBox.Show("Welcome Volunteer Member");
            }

            else
            {
                MessageBox.Show("Incorrect credentials");
            }
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
        }
    }
}
