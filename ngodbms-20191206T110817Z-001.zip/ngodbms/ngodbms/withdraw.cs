﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace ngodbms
{
    public partial class withdraw : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int IParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        public withdraw()
        {
            InitializeComponent();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Insert into Transition Values('" + textBox1.Text + "','" + dateTimePicker1.Text + "','" + textBox3.Text + "','" + richTextBox1.Text + "')";
            cmd.ExecuteNonQuery();
            con.Close();
            //textBox2.Text = "";
            textBox1.Text = "";
            dateTimePicker1.Text = "";
            textBox3.Text = "";
            richTextBox1.Text = "";

            MessageBox.Show("The transaction is saved successfully");
            Hide();
            cmhome cmh = new cmhome();
            cmh.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"|DataDirectory|\\Database.mdf\";Integrated Security=True");
        private void withdraw_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
