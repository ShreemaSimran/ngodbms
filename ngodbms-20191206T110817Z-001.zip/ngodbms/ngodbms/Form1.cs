﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace ngodbms
{
    public partial class Form1 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int IParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();







        bool isSlidingpanelexpanding;
        const int MaxSliderWidth = 160;
        const int MinSliderWidth = 60;
        public Form1()
        {
            InitializeComponent();

            isSlidingpanelexpanding = true;
            expandslidingpanelgui();
        }


        private void slidingpaneltogglebutton_Click(object sender, EventArgs e)
        {
            if(isSlidingpanelexpanding)
            {
                
            }
            slidingpaneltimer.Start();
        }

        private void slidingpaneltimer_Tick(object sender, EventArgs e)
        {
            if (isSlidingpanelexpanding)
            {
                slidingpanel.Width -= 30;
                if(slidingpanel.Width<=MinSliderWidth)
                {
                    isSlidingpanelexpanding = false;
                    slidingpaneltimer.Stop();
                    contractslidingpanelgui();

                    this.Refresh();
                }
            }
            else
            {
                slidingpanel.Width += 30;
                if (slidingpanel.Width >= MaxSliderWidth)
                {
                    isSlidingpanelexpanding = true;
                    slidingpaneltimer.Stop();
                    expandslidingpanelgui();

                    this.Refresh();
                }

            }
        }
        public void expandslidingpanelgui()
        {
            home.Text = "HOME";
            admin_login.Text = "ADMIN LOGIN";
            committee_member_login.Text = "COMMITTEE MEMBER LOGIN";
            volunteer_member_login.Text = "VOLUNTEER MEMBER LOGIN";
            doner.Text = "DONER";
            about.Text = "ABOUT";

            slidingpaneltogglebutton.Image = ngodbms.Properties.Resources.icons8_double_left_26;
            home.Image = null;
            admin_login.Image = null;
            committee_member_login.Image = null;
            volunteer_member_login.Image = null;
            doner.Image = null;
            about.Image = null;


        }
        public void contractslidingpanelgui()
        {
            

            home.Text = "";
            admin_login.Text = "";
            committee_member_login.Text = "";
            volunteer_member_login.Text = "";
            doner.Text = "";
            about.Text = "";

            slidingpaneltogglebutton.Image = ngodbms.Properties.Resources.icons8_double_right_26;
            home.Image = ngodbms.Properties.Resources.icons8_home_241;
            admin_login.Image = ngodbms.Properties.Resources.icons8_businessman_26__1_;
            committee_member_login.Image = ngodbms.Properties.Resources.icons8_conference_26;
            volunteer_member_login.Image = ngodbms.Properties.Resources.icons8_people_26;
            doner.Image = ngodbms.Properties.Resources.icons8_coins_24;
            about.Image = ngodbms.Properties.Resources.icons8_about_26;


        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (!cpanel.Controls.Contains(vmlogin_UserControl.Instance))
            {
                cpanel.Controls.Add(vmlogin_UserControl.Instance);
                vmlogin_UserControl.Instance.Dock = DockStyle.Fill;
                vmlogin_UserControl.Instance.BringToFront();
            }
            else
            {
                vmlogin_UserControl.Instance.BringToFront();
            }

        }

        private void home_Click(object sender, EventArgs e)
        {
            if(!cpanel.Controls.Contains(home_UserControl.Instance))
            {
                cpanel.Controls.Add(home_UserControl.Instance);
                home_UserControl.Instance.Dock = DockStyle.Fill;
                home_UserControl.Instance.BringToFront();
            }
            else
            {
                home_UserControl.Instance.BringToFront();
            }
        }

        private void admin_login_Click(object sender, EventArgs e)
        {
            if (!cpanel.Controls.Contains(alogin_UserControl.Instance))
            {
                cpanel.Controls.Add(alogin_UserControl.Instance);
                home_UserControl.Instance.Dock = DockStyle.Fill;
                home_UserControl.Instance.BringToFront();
            }
            else
            {
                alogin_UserControl.Instance.BringToFront();
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void committee_member_login_Click(object sender, EventArgs e)
        {
            if (!cpanel.Controls.Contains(cmlogin_UserControl.Instance))
            {
                cpanel.Controls.Add(cmlogin_UserControl.Instance);
                cmlogin_UserControl.Instance.Dock = DockStyle.Fill;
                cmlogin_UserControl.Instance.BringToFront();
            }
            else
            {
                cmlogin_UserControl.Instance.BringToFront();
            }

        }

        private void doner_Click(object sender, EventArgs e)
        {
            if (!cpanel.Controls.Contains(doner_UserControl.Instance))
            {
                cpanel.Controls.Add(doner_UserControl.Instance);
                doner_UserControl.Instance.Dock = DockStyle.Fill;
                doner_UserControl.Instance.BringToFront();
            }
            else
            {
                doner_UserControl.Instance.BringToFront();
            }

        }

        private void about_Click(object sender, EventArgs e)
        {
            if (!cpanel.Controls.Contains(about_UserControl.Instance))
            {
                cpanel.Controls.Add(about_UserControl.Instance);
                about_UserControl.Instance.Dock = DockStyle.Fill;
                about_UserControl.Instance.BringToFront();
            }
            else
            {
                about_UserControl.Instance.BringToFront();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void cpanel_Paint(object sender, PaintEventArgs e)
        {

           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            if(e.Button==MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
